/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FS7G27G2A01CBD
#define BSP_ROM_SIZE_BYTES (3145728)
#define BSP_RAM_SIZE_BYTES (655360)
#define BSP_DATA_FLASH_SIZE_BYTES (65536)
#define BSP_PACKAGE_BGA
#define BSP_PACKAGE_PINS (224)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
