/* generated configuration header file - do not edit */
#ifndef SF_ADC_PERIODIC_CFG_H_
#define SF_ADC_PERIODIC_CFG_H_
#define SF_ADC_PERIODIC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* SF_ADC_PERIODIC_CFG_H_ */
