/* generated configuration header file - do not edit */
#ifndef SF_MESSAGE_CFG_H_
#define SF_MESSAGE_CFG_H_
#define SF_MESSAGE_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define SF_MESSAGE_CFG_QUEUE_SIZE (16 * 4)
#endif /* SF_MESSAGE_CFG_H_ */
