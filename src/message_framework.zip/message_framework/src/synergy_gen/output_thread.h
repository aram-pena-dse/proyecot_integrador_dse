/* generated thread header file - do not edit */
#ifndef OUTPUT_THREAD_H_
#define OUTPUT_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus 
extern "C" void output_thread_entry(void);
#else 
extern void output_thread_entry(void);
#endif
#ifdef __cplusplus
extern "C"
{
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* OUTPUT_THREAD_H_ */
