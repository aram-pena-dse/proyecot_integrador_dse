/* generated thread header file - do not edit */
#ifndef COMPUTATION_THREAD_H_
#define COMPUTATION_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus 
extern "C" void computation_thread_entry(void);
#else 
extern void computation_thread_entry(void);
#endif
#ifdef __cplusplus
extern "C"
{
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* COMPUTATION_THREAD_H_ */
