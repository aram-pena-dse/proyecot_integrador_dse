/* generated thread header file - do not edit */
#ifndef SENSOR_THREAD2_H_
#define SENSOR_THREAD2_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus 
extern "C" void sensor_thread2_entry(void);
#else 
extern void sensor_thread2_entry(void);
#endif
#ifdef __cplusplus
extern "C"
{
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* SENSOR_THREAD2_H_ */
